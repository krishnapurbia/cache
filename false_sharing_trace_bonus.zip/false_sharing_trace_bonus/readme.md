// when using multiple threading , without solution to false sharing

Miss rate is 100% , as we are accesing the all four cons. address from all threads for reading which makes it 100% MISS for each Write
// ./L1simulate -t app1 -s 6 -E 2 -b 5 -o output.txt
 assume the block size is 16 byte then
  we can only place one instruction per block // each takes 16 bytes . More cache size needed <-- Disadv.
  
// with padding . Hence , false sharing can be tackled by padding one of the two method // but takes more cache

  // However , this trade off gives performance boost



// without padding <-- falsesharing happens
Simulation Parameters:
Trace Prefix: app1
Set Index Bits: 6
Associativity: 2
Block Bits: 4
Block Size (Bytes): 16
Number of Sets: 64
Cache Size (KB per core): 2
MESI Protocol: Enabled
Write Policy: Write-back, Write-allocate
Replacement Policy: LRU
Bus: Central snooping bus

Core 0 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 800
Idle Cycles: 1504
Cache Misses: 4
Cache Miss Rate: 100.00%
Cache Evictions: 0
Writebacks: 4
Bus Invalidations: 3
Data Traffic (Bytes): 128

Core 1 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 800
Idle Cycles: 1704
Cache Misses: 4
Cache Miss Rate: 100.00%
Cache Evictions: 0
Writebacks: 4
Bus Invalidations: 4
Data Traffic (Bytes): 128

Core 2 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 404
Idle Cycles: 2200
Cache Misses: 4
Cache Miss Rate: 100.00%
Cache Evictions: 0
Writebacks: 0
Bus Invalidations: 4
Data Traffic (Bytes): 64

Core 3 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 701
Idle Cycles: 2003
Cache Misses: 4
Cache Miss Rate: 100.00%
Cache Evictions: 0
Writebacks: 3
Bus Invalidations: 0
Data Traffic (Bytes): 112

Overall Bus Summary:
Total Bus Transactions: 16
Total Bus Traffic (Bytes): 432


// however using padding solution


  Simulation Parameters:
Trace Prefix: app1
Set Index Bits: 6
Associativity: 2
Block Bits: 4
Block Size (Bytes): 16
Number of Sets: 64
Cache Size (KB per core): 2
MESI Protocol: Enabled
Write Policy: Write-back, Write-allocate
Replacement Policy: LRU
Bus: Central snooping bus

Core 0 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 104
Idle Cycles: 0
Cache Misses: 1
Cache Miss Rate: 25.00%
Cache Evictions: 0
Writebacks: 0
Bus Invalidations: 0
Data Traffic (Bytes): 16

Core 1 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 104
Idle Cycles: 100
Cache Misses: 1
Cache Miss Rate: 25.00%
Cache Evictions: 0
Writebacks: 0
Bus Invalidations: 0
Data Traffic (Bytes): 16

Core 2 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 104
Idle Cycles: 200
Cache Misses: 1
Cache Miss Rate: 25.00%
Cache Evictions: 0
Writebacks: 0
Bus Invalidations: 0
Data Traffic (Bytes): 16

Core 3 Statistics:
Total Instructions: 4
Total Reads: 0
Total Writes: 4
Total Execution Cycles: 104
Idle Cycles: 300
Cache Misses: 1
Cache Miss Rate: 25.00%
Cache Evictions: 0
Writebacks: 0
Bus Invalidations: 0
Data Traffic (Bytes): 16

Overall Bus Summary:
Total Bus Transactions: 4
Total Bus Traffic (Bytes): 64

